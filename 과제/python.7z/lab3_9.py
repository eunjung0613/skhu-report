"""
챕터: day3
주제: bool
작성일: 2019. 9 .13
작성자: 김은정
"""
# bool 타입 변수 정의
a = True
b = False

c = 100
f = bool(c) # int인 c를 bool 타입으로 변환
print(f)
print(bool(0))

# [3,4,5]를 bool로 형변환하여 출력하라
print(bool([3,4,5]))

#[]는?
print(bool([]))