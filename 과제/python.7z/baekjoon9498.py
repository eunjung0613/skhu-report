m = int(input())
if (m>=90):
    print("A")
elif (m>=80):
    print("B")
elif (m>=70):
    print("C")
elif (m>=60):
    print("D")
elif (m<60):
    print("F")

ckw = {"고향" : "포항",
       "회사" : "어쩌구"}

del (ckw[고향])