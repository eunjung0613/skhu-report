"""
챕터: day4
주제: 반복문(while)문
문제:
사용자로부터 5개의 숫자를 입력받아, 이를 리스트에 저장한 후 합과 평균을 구하여 출력한다.
작성자: 김은정
작성일: 2018. 9. 27
"""
num = list((input("숫자 다섯개를 입력하세요: ").split(" ")))
num1 = len(num)
a = "" #더하기 값
d = "" #평균값
for i in range(num1):
    a += (int(num[i:]))
    d += (int(num[i:]))
d = a % num1
print(a)
print(d)